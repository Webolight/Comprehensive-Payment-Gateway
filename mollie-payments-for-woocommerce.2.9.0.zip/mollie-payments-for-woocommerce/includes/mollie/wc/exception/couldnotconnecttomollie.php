<?php
class Mollie_WC_Exception_CouldNotConnectToMollie extends Mollie_WC_Exception {}
