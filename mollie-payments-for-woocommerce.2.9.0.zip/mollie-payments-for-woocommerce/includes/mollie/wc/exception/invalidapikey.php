<?php
class Mollie_WC_Exception_InvalidApiKey extends Mollie_WC_Exception {}
