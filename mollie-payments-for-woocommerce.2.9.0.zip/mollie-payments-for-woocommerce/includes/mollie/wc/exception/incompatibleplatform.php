<?php
class Mollie_WC_Exception_IncompatiblePlatform extends Mollie_WC_Exception
{
    const API_CLIENT_NOT_INSTALLED    = 1000;
    const API_CLIENT_NOT_COMPATIBLE   = 2000;
}
